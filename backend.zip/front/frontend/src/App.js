import './App.css';
import { useState } from "react";

import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Head from "./component/head";

function App() {
  const [users, setUser] = useState([])
  const click = async () => {
    const res = await fetch("http://localhost:8080/");
    const data = await res.json();
    setUser(data);
    console.log(data, 'data===>')
  }

  const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: theme.palette.common.black,
      color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 14,
    },
  }));

  const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
      backgroundColor: theme.palette.action.hover,
    },
    // hide last border
    '&:last-child td, &:last-child th': {
      border: 0,
    },
  }));

return (
  <div>
    <Head title="Homepage" />
    <button onClick={click}>Click Me</button>
    <div >

    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 700 }} aria-label="customized table">
        <TableHead>
          <TableRow>
            <StyledTableCell>No</StyledTableCell>
            <StyledTableCell align="right">Name</StyledTableCell>
            <StyledTableCell align="right">Address</StyledTableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {users.map(user=>(
            <StyledTableRow key={user.No}>
              <StyledTableCell component="th" scope="row">
                {user.No}
              </StyledTableCell>
              <StyledTableCell align="right">{user.Name}</StyledTableCell>
              <StyledTableCell align="right">{user.Address}</StyledTableCell>
            </StyledTableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>

      
    </div>
  </div>
);
}

export default App;
