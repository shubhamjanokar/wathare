import express from 'express';
const app = express();
import mongoose from "mongoose";
import demo from './models/Demo.js';

const port = process.env.port || 8080


app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*')
    next()
})

app.get("/", async (req, res) => {
    // res.send({
    //     "name": "animals",
    //     "animals": [
    //         "Dog",
    //         "Cat",
    //         "Mouse",
    //         "Pig",
    //         "Bear"
    //     ],
    //     "hobbies": {
    //         "football": false,
    //         "reading": true
    //     }
    // });
    const demos = await demo.find({})
    res.json(demos);
    console.log(demos);
    // .then(data=>res.json(data))
    // .catch(error=>res.json(error))
})



mongoose.connect('mongodb+srv://root:Pratik%40123@mycluster.ovy7wrv.mongodb.net/Classwork?retryWrites=true&w=majority', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(() => {
    app.listen(port, () => console.log(`server run ${port}`))
}).catch((error) => console.log(`server not connect to ${port} ${error}`))
