import mongoose from "mongoose";
const demoSchema=new mongoose.Schema({
    No:{type:Number,required:true},
    Name:{type:String,required:true},
    Address:{type:String,required:true}
})
const demo=mongoose.model("demo",demoSchema);
export default demo;